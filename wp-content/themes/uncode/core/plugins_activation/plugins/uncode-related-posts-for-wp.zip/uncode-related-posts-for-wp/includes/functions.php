<?php

/**
 * @since  1.0.0
 * @access public
 *
 * @return RP4WP
 */
function RP4WP() {
	return RP4WP::get();
}